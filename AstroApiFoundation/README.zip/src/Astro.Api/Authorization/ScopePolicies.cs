namespace Astro.Api.Authorization;

public static class ScopePolicies
{
    public const string EphemerisRead = "ephemeris.read";
}
