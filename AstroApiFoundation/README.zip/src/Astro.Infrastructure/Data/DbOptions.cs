namespace Astro.Infrastructure.Data;

public sealed class DbOptions
{
    public string ConnectionString { get; set; } = "";
}
